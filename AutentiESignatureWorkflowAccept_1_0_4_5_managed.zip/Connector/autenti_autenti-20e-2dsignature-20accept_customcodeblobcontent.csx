using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

public class Script : ScriptBase
{
    private string _chosenFilePurpose;

    public override async Task<HttpResponseMessage> ExecuteAsync()
    {
        Context.Logger.LogInformation($"Received request with OperationId: {Context.OperationId}");
        Context.Logger.LogInformation("Starting request transformation...");
        await UpdateRequest();
        HttpResponseMessage response;
        switch (Context.OperationId)
        {
            case "Actions_availability":
                response = await TransformActionsAvailabilityResponse();
                break;
            case "Download_file":
                response = await TransformDownloadFileResponse();
                break;
            case "Document_change":
                response = await TransformDocumentChangeResponse();
                break;
            case "Get_files_info":
                response = await TransformGetFilesInfoResponse();
                break;
            case "GetTags":
                response = await TransformGetTagsResponse();
                break;
            default:
                Context.Logger.LogInformation("Sending the request forward...");
                response = await Context.SendAsync(Context.Request, CancellationToken).ConfigureAwait(false);
                Context.Logger.LogInformation($"Received response with status: {response.StatusCode}");
                break;
        }
        return response;
    }

    private async Task UpdateRequest()
    {
        switch (Context.OperationId)
        {
            case "Document_process_participants":
                await TransformDocumentProcessParticipantsRequest();
                break;
            case "Actions_availability":
                await TransformActionsAvailabilityRequest();
                break;
            case "Create_draft":
                await TransformDocumentProcessCreateRequest();
                break;
            case "Get_files_info":
                var uri = Context.Request.RequestUri;
                var queryString = uri.Query;
                var filePurposeValue = "";
                if (!string.IsNullOrEmpty(queryString))
                {
                    string trimmed = queryString;
                    if (trimmed.StartsWith("?"))
                    {
                        trimmed = trimmed.Substring(1);
                    }
                    // Rozbij na pary klucz=wartość
                    var parts = trimmed.Split(new[] { '&' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var part in parts)
                    {
                        // Szukamy klucza "filePurpose"
                        var idx = part.IndexOf('=');
                        if (idx > -1)
                        {
                            var key = part.Substring(0, idx);
                            var val = part.Substring(idx + 1);
                            if (key == "filePurpose")
                            {
                                filePurposeValue = Uri.UnescapeDataString(val);
                                break;
                            }
                        }
                    }
                }
                _chosenFilePurpose = filePurposeValue;
                break;
            default:
                Context.Logger.LogWarning($"Unknown OperationId: {Context.OperationId}");
                break;
        }
    }

    private async Task<HttpResponseMessage> TransformGetTagsResponse()
    {
        var response = await Context.SendAsync(Context.Request, CancellationToken).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode)
        {
            return response;
        }
        var raw = await response.Content.ReadAsStringAsync();
        var separators = new[] { "}\r\n{", "}\n{", "}{" };
        var segments = raw.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        var listOfObjects = new System.Collections.Generic.List<JObject>();
        foreach (var segment in segments)
        {
            var s = segment.Trim();
            if (!s.StartsWith("{")) s = "{" + s;
            if (!s.EndsWith("}")) s += "}";
            try
            {
                var parsedObject = JObject.Parse(s);
                listOfObjects.Add(parsedObject);
            }
            catch
            {
            }
        }
        var tagsArray = new JArray();
        foreach (var obj in listOfObjects)
        {
            tagsArray.Add(obj);
        }
        var outputJson = tagsArray.ToString(Newtonsoft.Json.Formatting.Indented);
        var newContent = new StringContent(outputJson, Encoding.UTF8, "application/json");
        var newResponse = new HttpResponseMessage(HttpStatusCode.OK)
        {
            Content = newContent
        };
        return newResponse;
    }

private async Task<HttpResponseMessage> TransformGetFilesInfoResponse()
{
    try
    {
        var response = await Context.SendAsync(Context.Request, CancellationToken).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode)
        {
            return response;
        }
        var originalJson = await response.Content.ReadAsStringAsync();
        var array = JArray.Parse(originalJson);
        var filtered = array.Where(o => (string)o["filePurpose"] == _chosenFilePurpose).ToList();

        if (filtered.Count == 0)
        {
            var notFoundContent = new StringContent("{\"message\": \"No file found for the chosen filePurpose\"}", Encoding.UTF8, "application/json");
            return new HttpResponseMessage(HttpStatusCode.NotFound)
            {
                Content = notFoundContent
            };
        }

        var first = filtered.First();
        var singleObject = new JObject
        {
            ["id"] = first["id"],
            ["filename"] = first["filename"],
            ["filePurpose"] = first["filePurpose"],
            ["mimeType"] = first["mimeType"]
        };

        var finalJson = singleObject.ToString(Newtonsoft.Json.Formatting.Indented);
        var newContent = new StringContent(finalJson, Encoding.UTF8, "application/json");
        return new HttpResponseMessage(HttpStatusCode.OK)
        {
            Content = newContent
        };
    }
    catch (Exception ex)
    {
        Context.Logger.LogError($"TransformGetFilesInfoResponse EXCEPTION: {ex}");
        var errorObj = new JObject
        {
            ["message"] = "Internal error in TransformGetFilesInfoResponse",
            ["error"] = ex.Message,
            ["stack"] = ex.StackTrace
        };
        return new HttpResponseMessage(HttpStatusCode.InternalServerError)
        {
            Content = new StringContent(errorObj.ToString(), Encoding.UTF8, "application/json")
        };
    }
}

    private async Task TransformDocumentProcessCreateRequest()
    {
        try
        {
            var requestData = await Context.Request.Content.ReadAsStringAsync();
            var input = JObject.Parse(requestData);
            var title = (string)input["title"];
            var description = (string)input["description"];
            var processLanguage = (string)input["processLanguage"];
            bool sendAsOrganization = (bool?)input["sendAsOrganization"] == true;
            var visualization = (string)input["visualization"] ?? string.Empty;
            var output = new JObject
            {
                ["title"] = title,
                ["description"] = description,
                ["processLanguage"] = processLanguage
            };
            if (sendAsOrganization)
            {
                var partiesArray = new JArray
                {
                    new JObject
                    {
                        ["party"] = new JObject
                        {
                            ["id"] = "PARTY-TENANT:SELF"
                        },
                        ["role"] = "SENDER"
                    }
                };
                output["parties"] = partiesArray;
            }
            if (!string.IsNullOrEmpty(visualization))
            {
                var constraintsArray = new JArray
                {
                    new JObject
                    {
                        ["constrainedActions"] = new JArray("ACTION:SIGNATURE_APPLICATION"),
                        ["classifiers"] = new JArray("CONSTRAINT-UNIQUE_TYPE:VISUALISATION"),
                        ["attributes"] = new JObject
                        {
                            ["visualisationId"] = $"VISUALISATION:{visualization}"
                        }
                    }
                };
                output["constraints"] = constraintsArray;
            }
            var transformedContent = Newtonsoft.Json.JsonConvert.SerializeObject(output, Newtonsoft.Json.Formatting.Indented);
            Context.Logger.LogInformation("TransformDocumentProcessCreateRequest - final payload:\n" + transformedContent);
            Context.Request.Content = new StringContent(transformedContent, Encoding.UTF8, "application/json");
        }
        catch (Exception ex)
        {
            Context.Logger.LogError(ex, "Wystąpił błąd podczas przetwarzania żądania dla Document_process_create");
        }
    }

    private async Task TransformActionsAvailabilityRequest()
    {
        var requestData = await Context.Request.Content.ReadAsStringAsync();
        var inputObject = JObject.Parse(requestData);
        var eventType = (string)inputObject["event_type"];
        if (!string.IsNullOrEmpty(eventType))
        {
            if (eventType == "Start document signing process")
            {
                eventType = "DOCUMENT_SENT";
            }
            else if (eventType == "Withdraw (stop) document process")
            {
                eventType = "DOCUMENT_WITHDRAWAL";
            }
            const string classifiers = "CHALLENGE_CLASSIFIER-UNIQUE_TYPE:ACTION_SELECTION";
            string xAssertion = $@"{{""classifiers"":[""{classifiers}""],""attributes"":{{""selectedIds"":[""EVENT_CLASSIFIER-UNIQUE_TYPE:{eventType}""]}}}}";
            string base64XAssertion = Convert.ToBase64String(Encoding.UTF8.GetBytes(xAssertion));
            Context.Request.Headers.Add("X-ASSERTION", base64XAssertion);
        }
    }

    private async Task<HttpResponseMessage> TransformActionsAvailabilityResponse()
    {
        HttpResponseMessage response = await Context.SendAsync(Context.Request, CancellationToken).ConfigureAwait(false);
        Context.Logger.LogInformation($"Received response with status: {response.StatusCode}");
        if (response.StatusCode == HttpStatusCode.Forbidden && response.Headers.Contains("x-challenge"))
        {
            string challengeHeader = response.Headers.GetValues("x-challenge").FirstOrDefault();
            string challengeJson = Encoding.UTF8.GetString(Base64UrlDecode(challengeHeader));
            Context.Logger.LogInformation($"Decoded challengeJson: {challengeJson}");
            var challengeObject = JObject.Parse(challengeJson);
            var newContent = new StringContent(challengeObject.ToString(), Encoding.UTF8, "application/json");
            var newResponse = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = newContent
            };
            Context.Logger.LogInformation("Successfully transformed the Actions_availability response.");
            return newResponse;
        }
        else
        {
            var originalResponseContent = await response.Content.ReadAsStringAsync();
            var newJsonObject = new JObject
            {
                { "body", JArray.Parse(originalResponseContent) }
            };
            var newContent = new StringContent(newJsonObject.ToString(), Encoding.UTF8, "application/json");
            var newResponse = new HttpResponseMessage(response.StatusCode)
            {
                Content = newContent
            };
            Context.Logger.LogInformation("Transformed the Actions_availability response by wrapping it in an object with 'body' property.");
            return newResponse;
        }
        return response;
    }

    private async Task<HttpResponseMessage> TransformDownloadFileResponse()
    {
        HttpResponseMessage response = await Context.SendAsync(Context.Request, CancellationToken).ConfigureAwait(false);
        if (response.IsSuccessStatusCode)
        {
            var byteArray = await response.Content.ReadAsByteArrayAsync();
            var base64String = Convert.ToBase64String(byteArray);
            var jsonResponse = new JObject
            {
                ["file"] = base64String
            };
            var newContent = new StringContent(jsonResponse.ToString(), Encoding.UTF8, "application/json");
            var newResponse = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = newContent
            };
            return newResponse;
        }
        return response;
    }

    private async Task TransformDocumentProcessParticipantsRequest()
    {
        try
        {
            var requestData = await Context.Request.Content.ReadAsStringAsync();
            var input = JObject.Parse(requestData);
            var participantType = (string)input["participantType"];
            var roleType = (string)input["roleType"];
            var signatureType = (string)input["signatureType"] ?? "none";
            var firstName = (string)input["participantData"]["firstName"];
            var lastName = (string)input["participantData"]["lastName"];
            var email = (string)input["participantData"]["contacts_attributes_email"];
            var constraints_attributes_priority = (string)input["participantData"]["constraints_attributes_priority"];
            bool otpSa = (bool?)(input["participantData"]["constraints_constrainedActions_otp_sa"]) == true;
            bool otpRsm = (bool?)(input["participantData"]["constraints_constrainedActions_otp_rsm"]) == true;
            bool otpRf = (bool?)(input["participantData"]["constraints_constrainedActions_otp_rf"]) == true;
            var phoneNumber = (string)input["participantData"]["constraints_constrainedActions_otp_phoneNumber"] ?? string.Empty;
            var companyName = (string)input["participantData"]["relationships_party_name"];
            var companyIdentificationSpace= (string)input["participantData"]["relationships_party_extIds_identificationSpace"];
            var companyIdentifier = (string)input["participantData"]["relationships_party_extIds_identifier"];
            var relationshipDescription = (string)input["participantData"]["relationships_attributes_relationshipDescription"];
            var rawSpace = companyIdentificationSpace ?? "PL";
            var finalIdentificationSpace = $"TAXID-{rawSpace}-NIP";
            var outputObject = new JObject();
            var partyObject = new JObject();
            outputObject["party"] = partyObject;
            partyObject["firstName"] = firstName;
            partyObject["lastName"] = lastName;
            var contactsArray = new JArray();
            var singleContact = new JObject
            {
                ["type"] = "CONTACT-TYPE:EMAIL",
                ["attributes"] = new JObject
                {
                    ["email"] = email
                }
            };
            contactsArray.Add(singleContact);
            partyObject["contacts"] = contactsArray;
            if (participantType == "company")
            {
                var relationshipsArray = new JArray();
                var singleRelationship = new JObject
                {
                    ["type"] = "PARTY_RELATIONSHIP-TYPE:MEMBER",
                    ["party"] = new JObject
                    {
                        ["name"] = companyName,
                        ["extIds"] = new JArray
                        {
                            new JObject
                            {
                                ["identificationSpace"] = finalIdentificationSpace,
                                ["identifier"] = companyIdentifier
                            }
                        }
                    },
                    ["attributes"] = new JObject
                    {
                        ["relationshipDescription"] = relationshipDescription
                    }
                };
                relationshipsArray.Add(singleRelationship);
                partyObject["relationships"] = relationshipsArray;
            }
            outputObject["role"] = roleType;
            var constraintsList = new JArray();
            if (roleType == "SIGNER" && signatureType != "none")
            {
                var signatureConstraint = new JObject
                {
                    ["constrainedActions"] = new JArray("ACTION:SIGNATURE_APPLICATION"),
                    ["classifiers"] = new JArray("CONSTRAINT-UNIQUE_TYPE:SIGNATURE_TYPE"),
                    ["attributes"] = new JObject
                    {
                        ["requiredClassifiers"] = new JArray(signatureType)
                    }
                };
                constraintsList.Add(signatureConstraint);
            }
            if ((roleType == "SIGNER" || roleType == "APPROVER") && !string.IsNullOrEmpty(constraints_attributes_priority))
            {
                var priorityObj = new JObject
                {
                    ["classifiers"] = new JArray("CONSTRAINT-UNIQUE_TYPE:PARTICIPATION_PRIORITY"),
                    ["attributes"] = new JObject()
                };
                if (int.TryParse(constraints_attributes_priority, out var intPriority))
                {
                    priorityObj["attributes"]["priority"] = intPriority;
                }
                else
                {
                    priorityObj["attributes"]["priority"] = constraints_attributes_priority;
                }
                constraintsList.Add(priorityObj);
            }
            if (otpSa)
            {
                var itemSa = new JObject
                {
                    ["constrainedActions"] = new JArray("ACTION:SIGNATURE_APPLICATION"),
                    ["classifiers"] = new JArray("CONSTRAINT-UNIQUE_TYPE:PHONE_NUMBER_VERIFICATION_REQUIRED"),
                    ["attributes"] = new JObject
                    {
                        ["phoneNumber"] = phoneNumber
                    }
                };
                constraintsList.Add(itemSa);
            }
            if (otpRsm)
            {
                var itemRsm = new JObject
                {
                    ["constrainedActions"] = new JArray("ACTION:READ_SENSITIVE_METADATA"),
                    ["classifiers"] = new JArray("CONSTRAINT-UNIQUE_TYPE:PHONE_NUMBER_VERIFICATION_REQUIRED"),
                    ["attributes"] = new JObject
                    {
                        ["phoneNumber"] = phoneNumber
                    }
                };
                constraintsList.Add(itemRsm);
            }
            if (otpRf)
            {
                var itemRf = new JObject
                {
                    ["constrainedActions"] = new JArray("ACTION:READ_FILES"),
                    ["classifiers"] = new JArray("CONSTRAINT-UNIQUE_TYPE:PHONE_NUMBER_VERIFICATION_REQUIRED"),
                    ["attributes"] = new JObject
                    {
                        ["phoneNumber"] = phoneNumber
                    }
                };
                constraintsList.Add(itemRf);
            }
            if (constraintsList.Count > 0)
            {
                outputObject["constraints"] = constraintsList;
            }
            var transformedContent =
                Newtonsoft.Json.JsonConvert.SerializeObject(outputObject, Newtonsoft.Json.Formatting.Indented);
            Context.Logger.LogInformation("TransformDocumentProcessParticipantsRequest - final payload:\n" + transformedContent);
            Context.Request.Content = new StringContent(transformedContent, Encoding.UTF8, "application/json");
        }
        catch (Exception ex)
        {
            Context.Logger.LogError(ex, "Wystąpił błąd podczas przetwarzania żądania dla Document_process_participants");
        }
    }

    private async Task<HttpResponseMessage> TransformDocumentChangeResponse()
    {
        HttpResponseMessage response = await Context.SendAsync(Context.Request, this.CancellationToken).ConfigureAwait(false);
        string responseContent = await response.Content.ReadAsStringAsync();
        JArray jsonArray = JArray.Parse(responseContent);
        if(jsonArray.Count > 0)
        {
            JObject firstObject = (JObject)jsonArray[0];
            string eventType = firstObject["eventType"].ToString();
            string id = firstObject["object"]["id"].ToString();
            string type = firstObject["object"]["type"].ToString();
            JObject newResponseContent = new JObject
            {
                ["body"] = $"eventType: {eventType}, id: {id}, type: {type}"
            };
            response.Content = new StringContent(newResponseContent.ToString(), Encoding.UTF8, "application/json");
        }
        return response;
    }

    private bool TryParseResponseBody(string responseContent, out string responseBody)
    {
        try
        {
            var responseObject = JObject.Parse(responseContent);
            if (responseObject.ContainsKey("body"))
            {
                responseBody = responseObject["body"].ToString();
                return true;
            }
        }
        catch (Exception ex)
        {
            Context.Logger.LogError($"Error parsing response content: {ex.Message}");
        }
        responseBody = null;
        return false;
    }

    private byte[] Base64UrlDecode(string base64Url)
    {
        string padded = base64Url.Length % 4 == 0
            ? base64Url
            : base64Url + "====".Substring(base64Url.Length % 4);
        string base64 = padded.Replace("_", "/").Replace("-", "+");
        return Convert.FromBase64String(base64);
    }
}